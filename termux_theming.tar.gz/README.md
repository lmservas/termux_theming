# termux_theming
A large collection of colorschemes, patched fonts, scripts for displaying/testing colors, my termux.properties, etc.

I go back and forth between ZSH and FISH shells but having been on a ZSH kick for a while now these instructions will be for setting up with ZSH/ohmyzsh.

*** This is poorly put together right now as I am very brand new to scripting and so it'll be some time but eventually I will package this correctly to where you just clone and run a script.

INSTRUCTIONS

That being said here is how we will do this. First backup your .zshrc file as well as your $HOME/.termux folder in case you'd like to revert to your previous setup.

Navigate to .termux:

cd
cd .termux

Download the termux_theming.tar from this repo:


